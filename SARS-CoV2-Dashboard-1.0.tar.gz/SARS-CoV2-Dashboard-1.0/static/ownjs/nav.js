// navigation script. Unifies calendar with svg tree and metadata
export { get_fastas, highlight_nodes }
import { force_vis_table } from "./svg_tree.js"

import { tabulate, columns, colnames } from "./metadata.js"

//import { draw_legend } from "./svg_legend.js"

import { draw_chart } from "./clonality_chart.js"

var highlight_nodes = new Set(["MN908947.3", "clade_19A", "clade_19B", "clade_20A", "clade_20B", "clade_20C"]);

// https://stackoverflow.com/questions/23593052/format-javascript-date-as-yyyy-mm-dd

var format = function date2str(x, y) {
    var z = {
        M: x.getMonth() + 1,
        d: x.getDate(),
        h: x.getHours(),
        m: x.getMinutes(),
        s: x.getSeconds()
    };
    y = y.replace(/(M+|d+|h+|m+|s+)/g, function(v) {
        return ((v.length > 1 ? "0" : "") + eval('z.' + v.slice(-1))).slice(-2)
    });

    return y.replace(/(y+)/g, function(v) {
        return x.getFullYear().toString().slice(-v.length)
    });
};

function get_clonality_time(start, end) {
    var conted = "getClonalities?start=";
    return conted.concat(start,"&end=", end);
};


function sync_tree(distance_model="strict",preselect_color="no"){
    $("#myChart").empty();
    $("#myLegend").empty();
    d3.json("generateMST")
        .header("Content-Type", "application/json")
        .post(JSON.stringify([sessionStorage.getItem("currentids"),distance_model]), e => {
            force_vis_table(e, 1.0, preselect_color);
        });
};

function sync_metadata(){
  $("#metadata_tab").empty();
  d3.json("getMetadata")
    .header("Content-Type", "application/json")
    .post(JSON.stringify(sessionStorage.getItem("currentids")), e => {tabulate(e, columns, colnames); });
};

function get_fastas(){
  d3.json("getFastas")
    .header("Content-Type", "application/json")
    .post(JSON.stringify(sessionStorage.getItem("currentids")), e => {
      //console.log(e);
      var link = document.createElement("a")
      link.href = "/output/currentids.fasta"
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    });
};

function sync_clonality(start, end){
    $("#myClone").empty();
    var form_start = format(start, "yyyy-MM-dd");
    var form_end = format(end, "yyyy-MM-dd");
    //var clone_time = get_clonality_time(form_start, form_end);
    var params = "getClonalities?start=".concat(form_start,"&end=",form_end);
    d3.json(params, d => {
      //console.log('Adjusting clonality plot for %s, %d nodes', clone_time, d.length);
      draw_chart(d);
    });
};

function sync_coloring_options(data_filter){
  //data_filter == "Surveillance" ? label.addClass("disabled") : label.removeClass("disabled");
  if (data_filter.startsWith("Outbreak")){ 
    $("#color_label_outbreak").addClass("active");
    $("#color_label_time").removeClass("active");
    $("#color_label_clades").removeClass("active");
  }
  else {
    $("#color_label_outbreak").removeClass("active");
    $("#color_label_time").removeClass("active");
    $("#color_label_clades").addClass("active");
  }
  //console.log(label);
};


function sync_current_ids(start, end, outbreak_filter, distance_model="strict", preselect_color="no"){
  var form_start = format(start, "yyyy-MM-dd");
  var form_end = format(end, "yyyy-MM-dd");
  var params = "getIDs?start=".concat(form_start,"&end=",form_end,"&filter=",outbreak_filter,"&dmodel=",distance_model);
  d3.json(params, d => { 
    sessionStorage.setItem("currentids", d); 
    sync_tree(distance_model, preselect_color);
    sync_metadata();
    sync_clonality(start, end);
  });
};

var start = new Date("2020-08-01");
var end = new Date();
//start.setMonth(start.getMonth() - 2);
var outbreak_filter = $("#outbreak_toggle > .active")[0].innerText;
var distance_model = "strict";
//console.log(sessionStorage.getItem("currentids"));


sync_current_ids(start,end,outbreak_filter,distance_model);
//console.log(current_ids);
//console.log(sessionStorage.getItem("currentids"));

// updating filter option
var toggle = $("#outbreak_toggle label").change( (e) => {
  outbreak_filter = e.currentTarget.innerText;
  if (outbreak_filter.startsWith("Outbreak")){
    sync_current_ids(start,end,outbreak_filter,distance_model,"Outbreak");
  }
  else{
    sync_current_ids(start,end,outbreak_filter,distance_model,"Clades");
  }
  sync_coloring_options(outbreak_filter);
});

// updating calendar
const picker1 = datepicker("#datepicker1", { dateSelected: start, 
  id: 1,
  maxDate: new Date(2023, 0, 1),
  minDate: new Date(2019, 0, 1),
  onSelect: instance => {
  start = instance.dateSelected;
  sync_current_ids(start,end,outbreak_filter,distance_model,"no");
  }
  });


const picker2 = datepicker("#datepicker2", { dateSelected: end, 
  id: 1,
  maxDate: new Date(2023, 0, 1),
  minDate: new Date(2019, 0, 1),
  onSelect: instance => {
  end = instance.dateSelected;
  sync_current_ids(start,end,outbreak_filter,distance_model,"no");
  }
});   
