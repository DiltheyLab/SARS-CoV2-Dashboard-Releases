export { draw_chart }
// http://bl.ocks.org/bobmonteverde/2070069 
// that was v3 d3 :(((

// https://bl.ocks.org/pstuffa/26363646c478b2028d36e7274cedefa6
// https://www.d3-graph-gallery.com/graph/line_several_group.html
// https://www.d3-graph-gallery.com/graph/line_confidence_interval.html

/*
// here the input data set should be tha output of get_d0 or get_d1 function
function draw_confidence(data, svg, xscale, yscale, color_conf) { 
  svg.append("path")
    .datum(data)
    .attr("fill", color_conf)
    .attr("stroke", "none")
    .attr("opacity", "0.4")
    .attr("d", d3.area()
      .x(function(d,i) { return xscale(i) })
      .y0(function(d) { return yscale(d[0]) })
      .y1(function(d) { return yscale(d[2]) })
      ) 
}

function draw_line(data, svg, xscale, yscale, color_line) {
  svg.append("path")
    .datum(data)
    .attr("fill", "none")
    .attr("stroke", color_line)
    .attr("stroke-width", 3)
    .attr("d", d3.line()
        .x(function(d,i) { return xscale(i) })
        .y(function(d) { return yscale(d[1]) })
        )

function get_d0(data) {
  var arr = new Array(data.length);
  for (var i = 0; i < arr.length; i++) {
    var d0 = data[i][1].p_d0
    arr[i] = d0;
  };
  return arr;
}

function get_d1(data) {
  var arr = new Array(data.length);
  for (var i = 0; i < arr.length; i++) {
    var d0 = data[i][1].p_d1
    arr[i] = d0;
  };
  return arr;
}


*/

// here the input data set should be tha output of get_d0 or get_d1 function
function draw_confidence(data, svg, xscale, yscale, color_conf) { 
  svg.append("path")
    .datum(data)
    .attr("fill", color_conf)
    .attr("stroke", "none")
    .attr("opacity", "0.4")
    .attr("d", d3.area()
      .x(function(d) { return xscale(new Date(d[0])) })
      .y0(function(d) { return yscale(d[1]) })
      .y1(function(d) { return yscale(d[3]) })
      ) 
}

function draw_line(data, svg, xscale, yscale, color_line) {
  svg.append("path")
    .datum(data)
    .attr("fill", "none")
    .attr("stroke", color_line)
    .attr("stroke-width", 3)
    .attr("d", d3.line()
        .x(function(d) { return xscale(new Date(d[0])) })
        .y(function(d) { return yscale(d[2]) })
        )
    
  
  svg.append("g")
    .selectAll(".dot")
    .data(data)
  .enter().append("circle") // Uses the enter().append() method
    .attr("class", "dot") // Assign a class for styling
    .attr("fill", color_line)
    .attr("cx", function(d, i) { return xscale(new Date(d[0])) })
    .attr("cy", function(d) { return yscale(d[2]) })
    .attr("r", 5);
  
}

function get_d0(data) {
  var arr = new Array(data.length);
  for (var i = 0; i < arr.length; i++) {
    arr[i] = new Array();
    var element = data[i]; 
    var d0 = element[1].p_d0;
    d0.unshift(element[0]);
    arr[i] = d0;
  };
  return arr;
}

function get_d1(data) {
  var arr = new Array(data.length);
  for (var i = 0; i < arr.length; i++) {
    arr[i] = new Array();
    var element = data[i]; 
    var d1 = element[1].p_d1;
    d1.unshift(element[0]);
    arr[i] = d1;
  };
  return arr;
}


function draw_legend(leg, labels){
  leg.selectAll("mydots")
      .data(labels)
      .enter()
      .append("circle")
        .attr("cx", 5)
        .attr("cy", function(d,i){ return i*25}) // 25 is the distance between dots
        .attr("r", 7)
        .style("fill", function(d){ return d.color});
  
  leg.selectAll("mylabels")
    .data(labels)
    .enter()
    .append("text")
      .attr("x", 15)
      .attr("y", function(d,i){ return 5 + i*25}) // 5 is where the first dot appears. 25 is the distance between dots
      .style("fill", function(d){ return d.color})
      .text(function(d){ return  d.name })
      .attr("text-anchor", "left")
      .style("alignment-baseline", "middle");
}

function draw_chart(json_data) {
  var color_d0 = "#034bbb";
  //var color_d1 = "#f5e605";
  var color_d1 = "#ffab00";
  
  //console.log(json_data);
  //console.log(json_data[16][1].p_d0)
  //console.log(json_data[0][0])
  //console.log(json_data.length);
  //var parser = d3.timeParse("%Y-%m-%d");
  //console.log(parser("2020-08-16"));
  
  var margin = {top: 30, right: 30, bottom: 30, left: 50};

  var svg = d3.select("#myClone"); // declaring to get width and height
  
  /*svg.append("text")
    .attr("x", +svg.attr("width")/2)
    .attr("y", 15) 
    .text("Clonality chart")
    .attr("text-anchor", "middle")
    .attr("font-weight", 500)
    .style("alignment-baseline", "middle");
  */
  
  
  var width = +svg.attr("width")-margin.left-margin.right;
  var height = +svg.attr("height")-margin.top-margin.bottom;

  
  // redeclaring to be able to work with translated to margins object
  var svg = d3.select("#myClone").append("g")
    .attr("transform", "translate(" + margin.left + "," + margin.top + ")"); 
  
  const xAxisTickFormatClonality = date =>
    date.getDate()+ "." + (date.getMonth()+1)+ "." + date.getFullYear()%100;
	
  var xScale = d3.scaleTime()
    .domain([new Date(json_data[0][0]), new Date(json_data[json_data.length -1][0])])
    .range([0, width]) 
    .nice();

  //const xAxisClonality = d3.axisBottom(xScale)
    
    
  /*
  var xScale = d3.scaleLinear()
    .domain([0, json_data.length+2]) //input
    .range([0, width]); // output
  */
  
  var yScale = d3.scaleLinear()
    .domain([0, 1]) // input 
    .range([height, 0]); // output 
  
  // 3. Call the x axis in a group tag
  svg.append("g")
      .attr("class", "xaxis_clonality")
      .attr("transform", "translate(0," + height + ")")
      .call(d3.axisBottom(xScale)
      	.tickFormat(xAxisTickFormatClonality)); // Create an axis component with d3.axisBottom

  // 4. Call the y axis in a group tag
  svg.append("g")
      .attr("class", "yaxis_clonality")
      .call(d3.axisLeft(yScale)); // Create an axis component with d3.axisLeft
  
  var d0_data = new Array();
  var d1_data = new Array();
  d0_data = get_d0(json_data);
  d1_data = get_d1(json_data);
  
  //console.log(d0_data);
  //console.log(d1_data);
  
  draw_confidence(d0_data, svg, xScale, yScale, color_d0);
  draw_confidence(d1_data, svg, xScale, yScale, color_d1);
  
  draw_line(d0_data, svg, xScale, yScale,  color_d0);
  draw_line(d1_data, svg, xScale, yScale, color_d1);
  
  // placing legend
  // https://stackoverflow.com/questions/41090920/how-to-position-the-legend-in-a-d3-chart
  var legendHolder = svg.append('g')
  // translate the holder to the right side of the graph
    .attr('transform', "translate(" + (margin.left + width - 150) + ",20)")

  var labels = [{"name":"distance 0", "color":color_d0}, {"name":"distance 1", "color":color_d1}];
  draw_legend(legendHolder, labels);

  
}
