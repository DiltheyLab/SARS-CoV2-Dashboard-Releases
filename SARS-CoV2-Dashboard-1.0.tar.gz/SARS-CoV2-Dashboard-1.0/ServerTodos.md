# 1. Basic setup

## Set up user
- set up new user `dashboard`
	- add to `wheel` group, which gives sudo access
	- set new `passwd`


##SSH
[Following advice from infosec-handbook](https://infosec-handbook.eu/blog/wss1-basic-hardening/)

- add public keys for ssh autenthentication
`ssh-copy-id <key.pub> dashboard@<ipaddress>`


- configure ssh daemon `/etc/ssh/sshd_config`
	- `PubkeyAuthentication no` → `PubkeyAuthentication yes`
- restart ssh daemon `sudo systemctl restart sshd.service`
- __Make sure login works without password before doing the following!!__

- configure ssh daemon `/etc/ssh/sshd_config`
	- `#PasswordAuthentication yes` → `PasswordAuthentication no `(disable password-based login)
	- `PermitRootLogin yes` → `PermitRootLogin no` (disable root login)
	- `#LogLevel INFO` → `LogLevel VERBOSE` (log login attempts)
	
- restart ssh daemon `sudo systemctl restart sshd.service`
- generate key pair `ssh-keygen` 
	- append public key to `authorized_keys` 
	- put private key as secret on github into `DASHBOARD_SSHKEY`

##uwsgi nginx 
### Install some packages
`sudo yum install epel-release`
`sudo yum update` this takes a while
update to new kernel etc. `sudo shutdown -r now`
`yum install pip3`
`yum install python3-devel`
`yum install nginx`
`yum install gcc-c++` needed for edlb
`pip3 install uwsgi`
`pip3 install biopython`
`pip3 install edlib`
`pip3 install networkx`
`pip3 install matplotlib`
`pip3 install scipy` needed for calculation of clonality confidence interavals

### ssl
[Following this tutorial](https://willy-tech.de/https-in-nginx-einrichten/)
```
sudo mkdir /etc/nginx/ssl
sudo openssl req -x509 -nodes -days 365 -newkey rsa:2048 -keyout /etc/nginx/ssl/nginx.key -out /etc/nginx/ssl/nginx.crt
```

##firewalld
CentOS is running a firewall, named `firewalld`
Allow https through: `sudo firewall-cmd --zone=public --permanent --add-service=https`
And http as well `sudo firewall-cmd --zone=public --permanent --add-service=http`
and restart the firewall  `sudo firewall-cmd --reload`
##nginx test
Once you have setup the firewall and generated the ssl keys, you should test that you get the nginx default page. So set up a preliminary server in `/etc/nginx/nginx.conf`
```
    server {
        listen       443 ssl http2 default_server;
        listen       [::]:443 ssl http2 default_server;
        server_name  covgen.uni-duesseldorf.de covgen.hhu.de;
        root         /usr/share/nginx/html;

        ssl_certificate "/etc/nginx/ssl/server.crt";
        ssl_certificate_key "/etc/nginx/ssl/server.key";
        ssl_session_cache shared:SSL:1m;
        ssl_session_timeout  10m;
        ssl_ciphers PROFILE=SYSTEM;
        ssl_prefer_server_ciphers on;

        # Load configuration files for the default server block.
        include /etc/nginx/default.d/*.conf;

        location / {
        }

        error_page 404 /404.html;
            location = /40x.html {
        }

        error_page 500 502 503 504 /50x.html;
            location = /50x.html {
        }
    }
```

Make sure the URL is set up by the ZIM (email to dns@uni-duesseldorf.de). Now when you browse to https://covgen.hhu.de after accepting the self-signed certificate you should see a nginx page. And you can now set up the real server.

# 2. Dashboard server setup
In this part the Dashboard server is set up and the link to github is established. To get started a folder is created for github to write to. 
## Github link
The uwsgi web server is started using the python-flask-webapp in this folder

`mkdir ~/sarscov2dash`

In the repository a _github action_ is defined to deploy the site when a push to the master branch is executed. For this to work another private/public SSH key is needed.
- generate public/private key pair
- add public key to autorized_keys on VM
Set up the secrets on github to allow copying of files from the repo to your production server. They are stored as secrets in the organization not the repository, so that they can be used by both the data repository and the site repository
- dashboard_datadir: `/home/dashboard/data`
- dashboard_sitedir: `/home/dashboard/sarscov2dash`
- dashboard_sshkey: private key that was just generated 

Now with a push to the master branch of the DiltheyLab/SARS-CoV2-Dashboard repository the dashboard webapp will be copied to this folder.

## uwsgi
Now it's time to get the dashboard web app running. It will be served by an uwsgi server, that will communicate with nginx. 
In the `sarscov2dash` folder an ini file is generated that will be used by uwsgi on startup. 

`~/sarscov2dash/site.ini`
```
[uwsgi]
#module = site:app
wsgi-file = site_dashboard.py
callable = app

master = true
processes = 5

socket = /home/dashboard/dashboard.sock
chmod-socket = 666
uid = dashboard
gid = www-data
vacuum = true

die-on-term = true
```

## Dashboard service
Now set up this dashboard service in `/etc/systemd/system` e.g. as `dashboardserver.service`
```
[Unit]
Description=uWSGI instance to serve dashboard
After=network.target

[Service]
User=dashboard
Group=www-data
WorkingDirectory=/home/dashboard/sarscov2dash
ExecStart=/usr/local/bin/uwsgi --ini site.ini

[Install]
WantedBy=multi-user.target
```

Test if this works with `sudo systemctl start dashboardserver`
And check for eventual errors with `sudo systemctl status dashboardserver` and fix those errors.

If everything worked you shoud see the file `~/dashboard.sock` which will be the socket that the nginx server can connect to. Now you can allow the user `dashboard` to restart the dasboard server.  This is needed for changes to the site from the github repository. 
in `/etc/sudoers` append the line:
```
dashboard       ALL=(ALL)       NOPASSWD: /usr/bin/systemctl restart dashboardserver.service
```

## Nginx
Now change the setup of the nginx server to communicate with the dashboard-webapp running on uwsgi.
in `/etc/nginx/nginx.conf`
```
    server {
        listen       443 ssl http2 default_server;
        listen       [::]:443 ssl http2 default_server;
        server_name  covgen.uni-duesseldorf.de covgen.hhu.de;
        root         /usr/share/nginx/html;

        #ssl_certificate "/etc/nginx/ssl/cert-11053807556332581322929959246.pem";
        #ssl_certificate_key "/etc/nginx/ssl/dashboard-privkey.pem";
        ssl_certificate "/etc/nginx/ssl/server.crt";
        ssl_certificate_key "/etc/nginx/ssl/server.key";
        ssl_session_cache shared:SSL:1m;
        ssl_session_timeout  10m;
        ssl_ciphers PROFILE=SYSTEM;
        ssl_prefer_server_ciphers on;

        # Load configuration files for the default server block.
        include /etc/nginx/default.d/*.conf;

        location / {
            include uwsgi_params;
            uwsgi_pass unix:///home/dashboard/dashboard.sock;
        }

        error_page 404 /404.html;
            location = /40x.html {
        }

        error_page 500 502 503 504 /50x.html;
            location = /50x.html {
        }
```

Now when you restart the nginx service (`sudo systemctl restart nginx`) it should be able to communicate with the uwsgi server and you should be able to see your webapp.
If your site can be reached via http on port 80 (you can email hhu-firewall@uni-duesseldorf.de to ask for this) it's advisable to send these requests to your site via https. To account for this in the config file prepend your server configuration in `/etc/nginx/nginx.conf` with
```
    server {
        listen       80;
        server_name _;
        return 301 https://$host$request_uri;
    }
```

## Properly signed SSL key
To get a SSL key that is signed by the DFN visit [public key service of the HHU](https://pki.pca.dfn.de/uni-duesseldorf-ca-g2/pub/pki)
Go to server certificate and try to follow the instructions. For the generation of the key-pair. You need to specify some properly defined attributes. One can use the following config file `dashboard.conf` to get an idea how the attributes are set correctly. 
```
[ req ]
default_bits       = 4096
distinguished_name = req_distinguished_name
req_extensions     = req_ext
prompt             = no
[ req_distinguished_name ]
countryName                 = DE
stateOrProvinceName         = Nordrhein-Westfalen
localityName               = Duesseldorf
organizationName           = Heinrich-Heine-Universitaet Duesseldorf
organizationalUnitName     = Institute of Medical Microbiology and Hospital Hygiene UKD
commonName                 = covgen.hhu.de <- CHANGE THIS
emailAddress               = dilthey@hhu.de <- CHANGE THIS
[ req_ext ]
subjectAltName = @alt_names
[alt_names]
DNS.1   = covgen.uni-duesseldorf.de <- CHANGE THIS
```
You can generate a key pair with the following command `sudo openssl req -new  -config dashboard.conf --keyout dashboard-privkey.pem -outform PEM -out dashboard.pem` 
The dashboard.pem will be the file that you upload to the aforementioned website. The site will generate a pdf that you have to sign and hand in to the person that is responsible for signing SSL certificates. At the time of writing the responsible person at the ZIM was Heide Unteregge (heide.unteregge@uni-duesseldorf.de).
She will then send you a new public key. This public key in conjunction with you private key (`dashboard-privkey.pem` in the given example) you can then copy to your server and specify in you nginx configuration.


