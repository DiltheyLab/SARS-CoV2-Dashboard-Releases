from Bio import pairwise2 as pw
from Bio import SeqIO
from argparse import ArgumentParser
from itertools import combinations
from collections import defaultdict
import edlib
import networkx as nx
from networkx.drawing.nx_agraph import graphviz_layout
import json
import matplotlib.pyplot as plt
import matplotlib.patches as patches
import os
import sys
import pickle

def update_distance_matrix(nseqs, equalsmode='N', pfile="distances.pkl"):
    # Update distance file
    if equalsmode == 'N':
        addedEquals=[("N", "A"), ("N", "G"),("N","T"),("N","C")]
    elif equalsmode == 'N2':
        addedEquals=[("N", "A"), ("N", "G"),("N","T"),("N","C"),("N","Y"),("N","R"),("N","S"),("N","W"),("N","K"),("N","M"),("C","Y"),("T","Y"),("R","A"),("R","G"),("S","G"),("S","C"),("W","A"),("W","T"),("K","G"),("K","T"),("M","A"),("M","C")]
    seqs = {}
    distances = {}
    if os.path.exists(pfile):
        with open(pfile, "rb") as f:
            seqs, distances=pickle.load(f)
    newids = nseqs.keys() - seqs.keys()
    seqs.update(nseqs)
    if newids:
        print("found " + str(len(newids)) + " new sequences ... ", end="", flush=True)
    for i1,i2 in combinations(seqs.keys(),2):
        s1, s2 = sorted([seqs[i1],seqs[i2]], key=lambda x:len(x))
        if (i1,i2) and (i2,i1) in distances:
            continue
        res = edlib.align(s1, s2,additionalEqualities=addedEquals, mode='HW')
        distances[(i1, i2)] = res["editDistance"]
        distances[(i2, i1)] = res["editDistance"]
    with open(pfile,"wb") as f:
        pickle.dump((seqs,distances), f)

def get_distances(nseqs, pickle_file=None):
    dlist = {}
    with open(pickle_file, "rb") as f:
        seqs, distances=pickle.load(f)
    for i1,i2 in combinations(nseqs.keys(),2):
        dlist[(i1,i2)] = distances[(i1,i2)]
    wlist = []
    for k1,k2 in dlist:
        dist = dlist[(k1, k2)]
        weight = 5 if dist == 0 else 1/(dist+1)**1
        wlist.append((k1,k2,weight))
    return wlist, dlist

def get_neighbourhood(original_ids, distance=3, pickle_file=None):
    nids = set()
    nids.update(original_ids)
    with open(pickle_file, "rb") as f:
        seqs, distances=pickle.load(f)
    for id1, id2 in distances:
        if id1 in original_ids: # matrix has symmetric entries=> only need to check id1
            if distances[(id1,id2)] <= distance: 
                nids.add(id2)
    #print(len(original_ids))
    #print(len(nids))
    return nids

def generate_graph(wlist, dlist, clade, date, short_id, outbreak_id):
    fg=nx.Graph()
    fg.add_weighted_edges_from(wlist)
    for n1, n2 in dlist.keys():
        fg[n1][n2]["dist"] = dlist[(n1,n2)] if dlist[(n1,n2)] != 0 else 0.1
        #fg[n1][n2]["dist"] = dlist[(n1,n2)]

    for idx in fg.nodes:
        if idx not in clade: print(idx + " not in clade")
        else: fg.nodes[idx]["clade"] = clade[idx]
        if idx not in short_id: print(idx + " not in short ids")
        else: fg.nodes[idx]["sid"] = short_id[idx]
        if idx not in date: print(idx + " not in date")
        else: fg.nodes[idx]["date"] = date[idx]
        if idx not in outbreak_id: print(idx + " not in outbreak_id")
        else: fg.nodes[idx]["outbreak_id"] = outbreak_id[idx]
    return nx.minimum_spanning_tree(fg,weight='dist')



def singular_plot(mst,path=None):
    color_schema = {
            'Wuhan': 'red',
            'Heinsberg': 'darkblue',
            'Duesseldorf': 'yellow',
            'Bonn': 'orange',
            'Essen': 'lightblue',
            'Tuebingen': 'blue',
            'Guetersloh1': 'lightgreen',
            'Guetersloh2': 'darkgreen',
            'negative' : 'black',
            'positive' : 'violet',
            'MN908947.3': 'red'
            }
    #fig = plt.figure()
    positions=nx.spring_layout(mst,iterations=350)
    leaves = {n for (n,d) in mst.degree() if d==1}

    
    origins_in_graph = set()
    for n in mst.nodes(data=True):
        color = 'black' if n[1]['clade'] not in color_schema else color_schema[n[1]['clade']]
        origins_in_graph.add(n[1]['clade'])
        if n[0] in leaves:
            nx.draw_networkx_nodes(mst,positions,nodelist=[n[0]],node_size=4,node_color=color_schema[n[1]['clade']])
        else:
            nsize = 12 if n[1]['clade'] != 'MN908947.3' else 30
            nx.draw_networkx_nodes(mst,positions,nodelist=[n[0]],node_size=nsize,node_color=color_schema[n[1]['clade']], edgecolors='black',linewidths=0.5)
    ezero=[(u,v) for (u,v,d) in mst.edges(data=True) if d['dist'] < 1]
    eone=[(u,v) for (u,v,d) in mst.edges(data=True) if d['dist'] == 1]
    e12=[(u,v) for (u,v,d) in mst.edges(data=True) if d['dist'] == 12]
    #print(e12)
    #print("length of ezero: " + str(len(ezero)))
    nx.draw_networkx_edges(mst, positions,edgelist=ezero, width=0.3,style='dotted')
    nx.draw_networkx_edges(mst, positions,edgelist=eone, width=0.4)
    ebig=[(u,v) for (u,v,d) in mst.edges(data=True) if d['dist'] >= 1]
    #print("length of ebig: " + str(len(ebig)))
    #print(ebig)
    nx.draw_networkx_edges(mst, positions,edgelist=ebig, width=0.5)
    #nx.draw_networkx_labels(mst, positions, font_size=5)
    edge_labels = nx.get_edge_attributes(mst, 'dist')
    #print(edge_labels)
    filtered_edge_labels = {}
    for edge,dist in edge_labels.items():
        if dist <2:
            continue
        filtered_edge_labels[edge] = dist
    nx.draw_networkx_edge_labels(mst, positions, edge_labels=filtered_edge_labels,label_pos=0.5,font_size=4)
    hlist = []
    llist = []

    for origin, col in color_schema.items():
        if origin not in origins_in_graph:
            continue
        c1 = patches.Circle((0.1,0.2),5,color=col)
        hlist.append(c1)
        llist.append(origin)
    plt.legend(hlist,llist,fontsize=8)
    #plt.legend([c1])
    #plt.legend()
    if path:
        plt.savefig(path,dpi=200)
    else:
        plt.show()

def get_metadata(ids, metadata_file, fasta_folder):
    clades = {}
    dates = {}
    sid = {}
    outbreak_ids = {}
    with open(metadata_file) as f:
        for line in f:
            short_id, fasta_id, run_date, sample_date, clade, outbreak_id = line.rstrip().split("\t")[0:6]
            if fasta_id not in ids and (ids != "all"):
                continue
            else:
                dates[fasta_id] = sample_date
                clades[fasta_id] = clade
                sid[fasta_id] = short_id
                outbreak_ids[fasta_id] = outbreak_id
    fastas = [os.path.join(fasta_folder, f) for f in os.listdir(fasta_folder) if os.path.isfile(os.path.join(fasta_folder, f)) and (f.endswith(".fa") or f.endswith(".fasta")) ]
    seqs = {}
    for ffile in fastas:
        for rec in SeqIO.parse(ffile, format="fasta"):
            if rec.id in ids or (ids == "all"):
                seqs[rec.id] = str(rec.seq)
    return (seqs, sid, clades, dates, outbreak_ids)

def get_data(fastafolder, ids):
    fastas = [os.path.join(fastafolder, f) for f in os.listdir(fastafolder) if os.path.isfile(os.path.join(fastafolder, f)) and (f.endswith(".fa") or f.endswith(".fasta")) ]
    seqs = {}
    for ffile in fastas:
        for rec in SeqIO.parse(ffile, format="fasta"):
            if rec.id in ids:
                seqs[rec.id] = str(rec.seq).upper()
    return seqs

def to_json(mst):
    return nx.readwrite.json_graph.node_link_data(mst)

if __name__ == '__main__':
    parser = ArgumentParser()
    parser.add_argument("infile") 
    parser.add_argument("reffile") 
    parser.add_argument("metafile") 
    parser.add_argument("distance_matrix")
    parser.add_argument("--update_distances", action="store_true", default=False)
    parser.add_argument("--json")
    args = parser.parse_args()
    refseq = ""
    print("Getting data ... ", end="")
    print("done.")
    seqs, fid2sid, clades, dates, outbreak_ids = get_metadata("all", args.metafile, args.infile) 
    #print(seqs.keys())
    # Filter certain entries
    filtered_seqs = {}
    for k,v in seqs.items():
        if clades[k] != 'Tuebingen':
            filtered_seqs[k] = v


    print("Calculating distances ... ", end="", flush=True)
    if (args.update_distances):
        update_distance_matrix(filtered_seqs, 'N', args.distance_matrix)
    wlist, distances = get_distances(filtered_seqs, args.distance_matrix)
    print("done.")


    print("Generating graph ... ", end="", flush=True)
    mst = generate_graph(wlist, distances , clades, dates, fid2sid, outbreak_ids)
    print("done.")

    if (args.json):
        with open(args.json, "w+") as f:
            data = to_json(mst)
            s = json.dumps(data)
            f.write(s)

    #singular_plot(mst, path="guetersloh.svg")
    print("Producing plot of graph with " + str(len(mst.nodes())) + " nodes ... ", end = "")
    singular_plot(mst)
    print("done.")

