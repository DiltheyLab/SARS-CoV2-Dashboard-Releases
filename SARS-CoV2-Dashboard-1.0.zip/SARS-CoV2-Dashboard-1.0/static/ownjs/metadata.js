// Source
// https://gist.github.com/jfreels/6734025 
import { highlight_nodes } from './nav.js';

function tabulate(data, columns, colnames) {
    var table = d3.select('table')
    var thead = table.append('thead')
    var	tbody = table.append('tbody');
    
    
    for (const name of Object.keys(data)) {
        //console.log(name);
        //console.log(data[name]);
        data[name]["name"] = name;
        //console.log(data[name]);
    };
    
    // append the header row
    thead.append('tr')
      .selectAll('th')
      .data(colnames).enter()
      .append('th')
        .text(function (colname) { return colname; });

    // create a row for each object in the data
    var rows = tbody.selectAll('tr')
      .data(Object.keys(data))
      .enter()
      .append('tr')
        .attr('id', function(d) { 
          //console.log(data[d]); 
          return "tr_".concat(data[d].short_id)})
        .attr('class', 'tablerow')
        .classed('table-success', d => highlight_nodes.has(data[d].name))
        .on('click', e => {
          var d = data[e];
          var ntxt = d3.select("#txt_".concat(d.short_id) );
          var ntr = d3.select("#tr_".concat(d.short_id) );
          if (highlight_nodes.has(d.name)){
            highlight_nodes.delete(d.name);
            ntxt.text("");
            ntr.classed('table-success', false);
          } else { 
            highlight_nodes.add(d.name);
            ntxt.text(d.short_id);
            ntr.classed('table-success', true);
          }
        });

    //console.log(rows);
    
    // create a cell in each row for each column
    var cells = rows.selectAll('td')
      .data(function (row) {
        return columns.map(function (column) {
          // console.log(data[row][column]);
          return {column: column, value: data[row][column]};
        });
      })
      .enter()
      .append('td')
        .text(function (d) { return d.value; });

  return table;
}

var columns = ['short_id','name','clade','run_date','sample_date','outbreak_id'];
var colnames = ['ID','Name','Clade','Sequencing Date','Sampling Date','Outbreak'];

export { tabulate, columns, colnames };
