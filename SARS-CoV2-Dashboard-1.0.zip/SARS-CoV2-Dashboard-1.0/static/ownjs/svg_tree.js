export { force_vis_table };
import { highlight_nodes } from './nav.js';
// --------Tutorial links ---------------
// https://bl.ocks.org/heybignick/3faf257bbbbc7743bb72310d03b86ee8

// Currently
// https://bootstrap-datepicker.readthedocs.io/en/latest/index.html

// ToDo
// https://stackoverflow.com/questions/30113571/d3-is-it-possible-to-prevent-object-to-exit-boundaries

var svg = d3.select("svg");
const width = +svg.attr("width");
const height = +svg.attr("height");



// This make sure special clades are always red
var schemeCategory21 = d3.schemeCategory20.slice();
schemeCategory21.unshift("#ff0033");
var color_clade_scale = d3.scaleOrdinal(schemeCategory21)
  .domain(["MN908947.3"]);
var schemeCategory12 = d3.schemeCategory10.slice();
schemeCategory12.unshift("#ff0033");
schemeCategory12.unshift("#d3d3d3");
var color_outbreak_scale = d3.scaleOrdinal(schemeCategory12)
  .domain(["-","*"]);


//var show_links = true;
//var color_by_clade = true;

//var lgf = svg.append("g")
//  .attr("class","linkgroup_father");
//var ngf = svg.append("g")
//  .attr("class","nodegroup_father");

var ggraph = null;

d3.selectAll("#view_toggle").selectAll("label").on("change", function() {
  force_vis_table(ggraph, 0.3);
});
d3.selectAll("#color_toggle").selectAll("label").on("change", function() {
  force_vis_table(ggraph, 0.05);
});

var simulation = d3.forceSimulation();
simulation
  .force("charge", d3.forceManyBody().strength(-20))
  .force("collision", d3.forceCollide().radius(8))
  .force("xforce", d3.forceX(width * 1/2))
  .force("yforce", d3.forceY(height * 1/2));



function draw_clade_legend(container, gnodes, color_scale){
  var clades = gnodes.map( function(d) { return d["clade"] });
  //console.log(clades);
  var clade_set = Array.from(new Set(clades));
  clade_set.sort();
  // Add one dot in the legend for each name.
  var dots = container.selectAll(".cladedots")
    .data(clade_set);
  var dots_enter = dots.enter()
    .append("circle")
      .attr("class", "cladedots")
      .attr("cx", 0)
      .attr("cy", function(d,i){ return 8 + i*25}) // 100 is where the first dot appears. 25 is the distance between dots
      .attr("r", 7)
      .style("fill", d  => color_scale(d));
  //dots = dots_enter.merge(dots);
  var labels = container.selectAll(".cladelabels")
    .data(clade_set)
  labels.enter().append("text")
      .attr("class", "cladelabels")
      .attr("x", 10)
      .attr("y", function(d,i){ return 12 + i*25}) // 100 is where the first dot appears. 25 is the distance between dots
      .style("fill", function(d){ return color_scale(d)})
      .text(function(d){ return  d=== "MN908947.3" ? "Wuhan" : "Clade " + d }) // a bit hacky, needs changing if we want to show different special clades
      .attr("text-anchor", "left")
      .style("alignment-baseline", "middle");
};

function draw_time_legend(container, dates, color_scale){
  var timebar_scale = d3.scaleSequential(d3.interpolateViridis)
      .domain([0, 200])
  var timebars = container.selectAll(".timebar")
      .data(d3.range(200), function(d) { return d; })
    .enter().append("rect")
      .attr("class", "timebar")
      .attr("x", function(d, i) { return i; })
      .attr("y", 0)
      .attr("height", 20)
      .attr("width", 1)
      .style("fill", function(d, i ) { return timebar_scale(d); })
  var labels = container.selectAll(".timelabels")
    .data(dates)
  labels.enter().append("text")
    .attr("class", "timelabels")
    .attr("x", (d,i) => i*200)
    .attr("y", 35)
    //.style("fill", function(d){ return color_scale(d3.isoParse(d))})
    .style("fill", "black")
    .text( d => d.getDate()+ "." + (d.getMonth()+1)+ "." + d.getFullYear()%100 )
    //.attr("stroke", "black")
    //.attr("stroke-width","0.5px")
    .attr("text-anchor", "left")
    .style("alignment-baseline", "top");
};

function draw_outbreak_legend(container, gnodes, color_scale){
  var outbreaks = gnodes.map( function(d) { return d["outbreak_id"] });
  var outbreak_set = Array.from(new Set(outbreaks));
  outbreak_set.sort();
  // Add one dot in the legend for each name.
  var dots = container.selectAll(".outbreakdots")
    .data(outbreak_set);
  var dots_enter = dots.enter()
    .append("circle")
      .attr("class", "outbreakdots")
      .attr("cx", 0)
      .attr("cy", function(d,i){ return 8 + i*25}) // 100 is where the first dot appears. 25 is the distance between dots
      .attr("r", 7)
      .style("fill", d  => color_scale(d));
  //dots = dots_enter.merge(dots);
  var labels = container.selectAll(".outbreaklabels")
    .data(outbreak_set)
  labels.enter().append("text")
      .attr("class", "outbreaklabels")
      .attr("x", 10)
      .attr("y", function(d,i){ return 12 + i*25}) // 100 is where the first dot appears. 25 is the distance between dots
      .style("fill", function(d){ return color_scale(d)})
      .text(function(d){ 
        if (d === "*") 
          return "Wuhan"
        else if (d === "-")
          return "Surveillance"
        else 
          return "Outbreak "  + d })
      .attr("text-anchor", "left")
      .style("alignment-baseline", "middle");
};


function force_vis_table(graph, nalpha, preselect_color="no") {
  //show_links= !d3.select("#view_toggle").property("checked");
  var show_links = d3.select('input[name="view_btnradio"]:checked').node().id == 'view_btnradio_mst';
  var color_by = preselect_color === "no" ? d3.select('#color_toggle').select(".active").node().innerText : preselect_color
  var outbreak_choice = d3.select("#outbreak_toggle").select(".active").node().innerText;

  ggraph = graph;

  simulation.alpha(nalpha);
  simulation.alphaTarget(0).restart();
  const margin = { top: 10, right: 100, bottom: 60, left: 50 };
  const innerwidth = width - margin.left - margin.right
  
  var time_01_scale = d3.scaleTime()
    .domain(d3.extent(graph.nodes, (d) => d3.isoParse(d.date)))
    .range([0,1])
  function iso_color_scale(isodate) {
    return d3.interpolateViridis(time_01_scale(d3.isoParse(isodate)));
  }
  
  var legendc = svg.selectAll(".legend_container")
    .data([4]);
  legendc.enter()
    .append("g")
    .attr("class", "legend_container")
    .attr("transform", "translate(8,8)");
  
  legendc = svg.select(".legend_container");
 
  //var dots = legendc.selectAll(".mydots").data([]);
  //var dots = legendc.selectAll(".mydots").data([1,2]);
  //dots.remove().exit();
  var dots;


  legendc.selectAll("*").remove();
  if (color_by == "Clades") {
    draw_clade_legend(legendc, graph.nodes, color_clade_scale);
  }
  else if (color_by == "Sampling Time") {
    draw_time_legend(legendc, d3.extent(graph.nodes,d => d3.isoParse(d.date)), iso_color_scale);
  }
  else if (color_by == "Outbreak") {
    draw_outbreak_legend(legendc, graph.nodes, color_outbreak_scale);
  }
  


  var lgf = svg.selectAll(".linkgroup_container")
    .data([2]);
  lgf = lgf
    .enter()
    .append("g")
      .attr("class", "linkgroup_container")
      .attr("transform", "translate(" + (margin.left) + ", " + margin.top + ")")
    .merge(lgf);
  var ngf = svg.selectAll(".nodegroup_container")
    .data([3]);
  ngf = ngf
    .enter()
    .append("g")
      .attr("class", "nodegroup_container")
      .attr("transform", "translate(" + (margin.left) + ", " + margin.top + ")")
    .merge(ngf);
    
  var xaxisgdl = svg.selectAll(".xaxis_graph")
    .data(show_links ? [] : [1])
  var xaxisgdle = xaxisgdl.enter()
    .append('g')
      .attr("class", "xaxis_graph")
      .attr("transform", "translate(" + (margin.left) + ", " + (height+margin.top-50)+ ")")
    .lower();

  xaxisgdl.exit().remove()
  var xscale = d3.scaleTime()
    .domain(d3.extent(graph.nodes, (d) => d3.isoParse(d.date)))
    .range([0, innerwidth])
    .nice();

  const xAxisTickFormat = date =>
    date.getDate()+ "." + (date.getMonth()+1)+ "." + date.getFullYear()%100; 

  const xAxis = d3.axisBottom(xscale)
    .tickFormat(xAxisTickFormat)
    .tickSize(-height)
    .ticks(7);

  
  //xAxisG.select('.domain').remove();
  xAxis(xaxisgdle);
  svg.selectAll(".xaxis_graph").selectAll("path")
    .remove()
    
    

  var linkdl = lgf.selectAll(".linkgroup")
    .data(show_links ? graph.links : []);
  //linkdl.exit().remove();/ess

  var linkgroups = linkdl.enter()
    .append("g")
      .attr("class", "linkgroup")
  

  //var linkline = linkdl.enter()
  linkgroups.append("line")
    .attr("class", "linklines")
    .attr("stroke-width", "2px")
    .attr("stroke", "grey");
  linktext = linkgroups.append("text")
    .attr("class", "linktexts")
    .attr("x", d => (d.source.x + d.target.x)/2 )
    .attr("y", d => (d.source.y + d.target.y)/2 )
    .attr("font-size", 5)
    .text( d => d.weight );

  linkgroups = linkgroups.merge(linkdl)
  var linkline = linkgroups.selectAll(".linklines")
  var linktext = linkgroups.selectAll(".linktexts")
  
  linkdl.exit().remove();
      

  var ngdl = ngf.selectAll(".nodegroup")
    .data(show_links 
      ? graph.nodes 
      : graph.nodes.filter(d => d.date != "*"),
    d => d.id);
  ngdl.exit().remove();
  //console.log(ngdl)

  var nodes = ngdl.enter()
    .append("g")
      .attr("class", "nodegroup")
      .attr("transform", "translate(100, 100 )");

  nodes.append("title")
    .text(d => d.id);

  //var ngdl = nodes.enter().append("g");

    
  var ntext = nodes.append("text")
    .attr("x", (d) => 7)
    .attr("y", (d) => 3)
    .attr("class", "nodetext")
    .attr("id", d => "txt_".concat(d.sid))
    .text( d => {
      return highlight_nodes.has(d.id) ? d.id == "MN908947.3" ? "Wuhan" : d.sid : ""
    });
    //nodes.selectAll("text").text( d => highlight_nodes.has(d.id) ? d.id == "MN908947.3" ? "Wuhan" : d.id : "");
  //var ntext = nodegroups.selectAll(".nodetext");
  //console.log(nodes);
  var radius = 5;
  var rscale = d3.scaleTime()
    .domain(d3.extent(graph.nodes, (d) => d3.isoParse(d.date)))
    .range([4, 5]);



  var circles= nodes.append("circle");
    //.attr("fill", d => color_clade_scale(d.clade) );


  nodes=nodes.merge(ngdl);
  nodes.selectAll("circle")
    .attr("fill", d => {
      if (color_by == "Clades")
        return color_clade_scale(d.clade);
      else if (color_by == "Sampling Time")
        return iso_color_scale(d.date);
      else if (color_by == "Outbreak")
        return color_outbreak_scale(d.outbreak_id);
    })
    .attr("r", d => ((d.date === "*" ) || (! show_links)) ? 4 : rscale(d3.isoParse(d.date)))
    .style("stroke", d => d.date === "*" ? "#000" : "#fff");

  nodes.on('click', d => {
    var ntxt = nodes.select("#txt_".concat(d.sid) );
    var ntr = d3.select("#tr_".concat(d.sid) );
    if (highlight_nodes.has(d.id)){
      highlight_nodes.delete(d.id)
      ntxt.text("");
      ntr.classed('table-success', false);
    } else { 
      highlight_nodes.add(d.id);
      ntxt.text(d.sid);
      ntr.classed('table-success', true);
    }
  });
  
  nodes.call(d3.drag()
      .on("start", dragstarted)
      .on("drag", dragged)
      .on("end", dragended));


  //var simulation = d3.forceSimulation()

  //var forceLink = simulation.force("link");  
  var xForce = simulation.force("xforce");  
  xForce
    .x( 
      show_links
        ? innerwidth*1/2 
        : d => d.date === "*" ? innerwidth/2 : xscale(d3.isoParse(d.date)))
    .strength( show_links ? 0.1 : 1.0);
      //: innerwidth*2/3);
  simulation.nodes(graph.nodes)
    .on("tick", ticked);
  simulation.force("link", d3.forceLink(graph.links)
    .id( d => d.id )
    .distance( d => d.dist*1.2+2)
    .strength( show_links ? 0.6 : 0));

  var repulsion_scale = d3.scaleLinear()
    .domain([10,200])
    .range([-100,-20])
    .clamp(true);
  

  simulation.force("charge").strength( show_links ? repulsion_scale(graph.nodes.length) : 0);

  function ticked() {
    linkline
      .attr("x1", d => d.source.x )
      .attr("y1", d => d.source.y )
      .attr("x2", d => d.target.x )
      .attr("y2", d => d.target.y);
    linktext
      .attr("x", d => (d.source.x + d.target.x)/2 )
      .attr("y", d => (d.source.y + d.target.y)/2 )
      .text( d => d.dist !== 0.1
        ? d.dist 
        : ""
      );

    nodes
      .attr("transform", d => "translate(" + d.x + "," + d.y + ")");

      
    //nodes.selectAll("text").text( d => highlight_nodes.has(d.id) ? d.id == "MN908947.3" ? "Wuhan" : d.id : "");
  }

  function dragstarted(d) {
    if (!d3.event.active) simulation.alphaTarget(0.2).restart();
    d.fx = d.x;
    d.fy = d.y;
  }

  function dragged(d) {
    //console.log(event);
    d.fx = d3.event.x;
    d.fy = d3.event.y;
  }

  function dragended(d) {
    if (!d3.event.active) simulation.alphaTarget(0);
    d.fx = null;
    d.fy = null;
  }

}

