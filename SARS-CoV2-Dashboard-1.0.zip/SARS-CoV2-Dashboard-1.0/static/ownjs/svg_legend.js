var leg = d3.select("#myLegend"); 

function draw_legend(graph, color){
    //console.log(graph);
    //console.log(color);
    //leg.append("circle").attr("cx",200).attr("cy",130).attr("r", 6).style("fill", "#69b3a2");
    
    var clades = graph.nodes.map( function(d) { return d["clade"] });
    //console.log(clades);
    var clade_set = Array.from(new Set(clades));
    clade_set.sort();
    //console.log(clade_set);
    
    // Add one dot in the legend for each name.
    leg.selectAll("mydots")
      .data(clade_set)
      .enter()
      .append("circle")
        .attr("cx", 100)
        .attr("cy", function(d,i){ return 100 + i*25}) // 100 is where the first dot appears. 25 is the distance between dots
        .attr("r", 7)
        .style("fill", function(d){ return color(d)});
    
    leg.selectAll("mylabels")
      .data(clade_set)
      .enter()
      .append("text")
        .attr("x", 120)
        .attr("y", function(d,i){ return 104 + i*25}) // 100 is where the first dot appears. 25 is the distance between dots
        .style("fill", function(d){ return color(d)})
        .text(function(d){ return  d=== "MN908947.3" ? "Wuhan" : "Clade " + d }) // a bit hacky, needs changing if we want to show different special clades
        .attr("text-anchor", "left")
        .style("alignment-baseline", "middle");

};

export {draw_legend};
