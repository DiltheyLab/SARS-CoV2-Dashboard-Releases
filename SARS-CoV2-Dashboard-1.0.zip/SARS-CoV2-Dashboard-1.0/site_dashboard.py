from flask import Flask, url_for, render_template, request, redirect, flash, send_from_directory, make_response, json, Response, send_file
import requests
from threading import Thread
from collections import defaultdict
from markupsafe import escape
import os
import uuid
import min_span_tree
from datetime import date
from backports.datetime_fromisoformat import MonkeyPatch

MonkeyPatch.patch_fromisoformat()


app = Flask(__name__)

app.config.from_object('default_settings')
app.config.from_envvar('DASHBOARD_SETTINGS', silent=True)

def get_data(ids):
    clades = {}
    dates = {}
    sid = {}
    with open(app.config['METADATA_FILE']) as f:
        for line in f:
            short_id, fasta_id, run_date, sample_date, clade = line.rstrip().split("\t")
            if fasta_id not in ids:
                continue
            else:
                dates[fasta_id] = sample_date
                clades[fasta_id] = clade
                sid[fasta_id] = short_id
    fastas = [os.path.join(app.config['FASTA_FOLDER'], f) for f in os.listdir(app.config['FASTA_FOLDER']) if os.path.isfile(os.path.join(app.config['FASTA_FOLDER'], f)) and (f.endswith(".fa") or f.endswith(".fasta")) ]
    seqs = {}
    for ffile in fastas:
        for rec in SeqIO.parse(ffile, format="fasta"):
            if rec.id in ids:
                seqs[rec.id] = str(rec.seq)
    return (seqs, sid, clades, dates)

@app.route('/',methods=['GET', 'POST'])
@app.route('/index.html',methods=['GET', 'POST'])
def json_test():
    return render_template('index.html')

@app.route('/output/currentids.fasta',methods=['GET'])
def output():
    return send_file(app.config["OUTPUT_FOLDER"] + "/currentids.fasta", attachment_filename="dashboard.fasta", as_attachment=True)

@app.route('/getFastas',methods=['POST'])
def getFastas():
    ids = request.get_json(force=True).split(",")
    seqs = min_span_tree.get_data(app.config['FASTA_FOLDER'], ids)
    fasta_text = ""
    for k,v in seqs.items():
        fasta_text += ">" + k + "\n"
        fasta_text += v + "\n"
    fasta_text = fasta_text.rstrip()
    with open(app.config['OUTPUT_FOLDER'] + "currentids.fasta", "w+") as f:
        f.write(fasta_text)
    return "ok"
    

@app.route('/getIDs',methods=['GET'])
def getIDs():
    potentialIDs = set()
    startp = request.args.get("start")
    endp = request.args.get("end")
    outbreak_filter = request.args.get("filter")
    distance_model = request.args.get("dmodel") # We need to know which distance model to get the correct neighbours
    if not (startp and endp and outbreak_filter and distance_model) :
        return "You must specify 'start', 'end', 'dmodel' and 'filter' parameters"
    if distance_model == "strict": distance_matrix_file = app.config['DISTANCE_MATRIX_FILE_STRICT']
    elif distance_model == "lenient": distance_matrix_file = app.config['DISTANCE_MATRIX_FILE_LENIENT']
    else:
        return "Only strict and lenient distance models are supported"

    start_date = date.fromisoformat(startp)
    end_date = date.fromisoformat(endp)

    with open(app.config['METADATA_FILE'], "r") as f:
        for lnr, liner in enumerate(f):
            line = liner.rstrip()
            if lnr == 0:
                continue
            if len(line.split("\t")) < 6:
                continue #todo log this
            outbreak_id = line.split("\t")[5]
            if outbreak_filter == "All": pass
            elif outbreak_filter == "Surveillance":
                if outbreak_id not in "-*": 
                    continue
            elif outbreak_filter.startswith("Outbreak"):
                if outbreak_id == "-": 
                    continue
                
            sampling_date = line.split("\t")[3]
            if sampling_date == "*": #wildcard for special ids
                potentialIDs.add(line.split("\t")[1])
            elif sampling_date == "-": #do not use these
                continue
            else:
                cdate = date.fromisoformat(sampling_date)
                if (cdate >= start_date and cdate <= end_date ):
                    potentialIDs.add(line.split("\t")[1])
        if outbreak_filter == "Outbreaks with neighbours":
            nids = min_span_tree.get_neighbourhood(potentialIDs, distance=10, pickle_file=distance_matrix_file)
            potentialIDs = nids
            potentialIDs = potentialIDs - set(["clade_19A", "clade_19B", "clade_20A", "clade_20B", "clade_20C"])
    return json.dumps(list(potentialIDs))

@app.route('/getClonalities',methods=['GET'])
def getClonalities():
    validDates = []
    startp = request.args.get("start")
    endp = request.args.get("end")
    if not (startp and endp) :
        return "You must specify 'start' and 'end' parameters"
    start_date = date.fromisoformat(startp)
    end_date = date.fromisoformat(endp)
    with open(app.config['CLONALITY_FILE']) as f:
        clonalities = json.load(f)
    clonalities_needed = {}

    for date_iso, values in clonalities.items():
        cdate = date.fromisoformat(date_iso)
        if (cdate >= start_date and cdate <= end_date ):
            clonalities_needed[date_iso] = values
    sorted_clonalities  = sorted(clonalities_needed.items())
    return json.dumps(sorted_clonalities)

@app.route('/getDateRange',methods=['GET'])
def getDateRange():
    dates = []
    with open(app.config['METADATA_FILE'], 'r') as f:
        for lnr, line in enumerate(f):
            if lnr == 0:
                continue
            if line.split("\t")[3] in {"-","*"}:
                continue
            cdate = date.fromisoformat(line.split("\t")[3])
            dates.append(cdate)
    return json.dumps((min(dates), max(dates)))

@app.route('/generateMST', methods=['POST'])
def generate_mst():
    fasta_ids, distance_model = request.get_json(force=True) 
    if distance_model == "strict": distance_matrix_file = app.config['DISTANCE_MATRIX_FILE_STRICT']
    elif distance_model == "lenient": distance_matrix_file = app.config['DISTANCE_MATRIX_FILE_LENIENT']
    #print(distance_matrix_file)
    #print(fasta_ids)
    seqs, fid2sid, clades, dates, outbreak_id = min_span_tree.get_metadata(fasta_ids, app.config['METADATA_FILE'], app.config['FASTA_FOLDER'])
    wlist, dlist = min_span_tree.get_distances(seqs, distance_matrix_file)
    mst = min_span_tree.generate_graph(wlist, dlist, clades, dates,fid2sid, outbreak_id)
    return json.dumps(min_span_tree.to_json(mst))

@app.route('/getMetadata', methods=['POST'])
def get_metadata():
    ids = request.get_json(force=True) 
    metadata = {}

    with open(app.config['METADATA_FILE']) as f:
        for lnr,line in enumerate(f):
            if lnr == 0:
                continue
            short_id, fasta_id, run_date, sample_date, clade, outbreak_id = line.split("\t")[:6]
            if fasta_id not in ids:
                continue
            else:
                metadata[fasta_id] = {'short_id': short_id, 'run_date': run_date, 'sample_date': sample_date, 'clade': clade, 'outbreak_id': outbreak_id}
    return json.dumps(metadata)


@app.route('/test_metadata')
def test_meta():
    res = requests.get('http://localhost:5000/getIDs?start=2020-02-12&end=2020-10-13&filter="All"&dmodel=strict')
    ids_json = res.json()
    res2 = requests.post('http://localhost:5000/getMetadata', json=ids_json)
    return res2.text

@app.route('/test_mst_json')
def test_mst():
    res = requests.get('http://localhost:5000/getIDs?start=2020-02-12&end=2020-10-13&filter="All"&dmodel=strict')
    ids_json = res.json()
    res2 = requests.post('http://localhost:5000/generateMST', json=[ids_json,"strict"])
    return res2.text

@app.route('/contact',methods=['GET'])
def contact_us():
    return render_template('contact_us.html')

@app.route('/about',methods=['GET'])
def about_proj():
    return render_template('about_this_project.html')

@app.route('/partners',methods=['GET'])
def proj_partners():
    return render_template('project_partners.html')

@app.route('/testnav',methods=['GET'])
def testnav():
    return render_template('test_navbar.html')



